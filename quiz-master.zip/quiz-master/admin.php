<?php include('home.html')?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		ul{
			list-style-type: none;
			margin:0;
			padding: 0;
			text-align: center;
		}
		li{
			display: inline;
			margin:40px;
			padding: 20px;

		}
		li a{
			
			width: 250px;
		}
	</style>
</head>
<body>

<a href="/" class="btn btn-successs">Home</a>home.
<ul>
	<li><a href="create-quiz.php"class="btn btn-primary mb-2">Create Quiz</a></li>
	<li><a href="result.php"class="btn btn-primary mb-2">See result</a></li>
	<li><a href=""class="btn btn-primary mb-2">Logout</a></li>
</ul>
</body>
