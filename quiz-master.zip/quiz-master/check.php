<?php
 include('db_connect.php'); 
echo $_POST['answer'];
?>