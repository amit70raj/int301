<?php include('home.html');

?>
<h3 class="text-center">Result</h3>
	<h1 class="text-center">You Lost</h1>
	<a   href="user.php">Try again</a>